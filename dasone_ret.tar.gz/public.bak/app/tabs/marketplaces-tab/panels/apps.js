/* -------------------------------------------------------------------------- */
/* Copyright 2002-2017, OpenNebula Project, OpenNebula Systems                */
/*                                                                            */
/* Licensed under the Apache License, Version 2.0 (the "License"); you may    */
/* not use this file except in compliance with the License. You may obtain    */
/* a copy of the License at                                                   */
/*                                                                            */
/* http://www.apache.org/licenses/LICENSE-2.0                                 */
/*                                                                            */
/* Unless required by applicable law or agreed to in writing, software        */
/* distributed under the License is distributed on an "AS IS" BASIS,          */
/* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   */
/* See the License for the specific language governing permissions and        */
/* limitations under the License.                                             */
/* -------------------------------------------------------------------------- */

define(function(require){
  /*
    DEPENDENCIES
   */

  var Locale = require('utils/locale');
  var MarketPlaceAppsTable = require('tabs/marketplaceapps-tab/datatable');

  /*
    CONSTANTS
   */

  var PANEL_ID = require('./apps/panelId');
  var MARKETPLACEAPPS_TABLE_ID = PANEL_ID + "MarketPlaceAppsTable"
  var XML_ROOT = "MARKETPLACE"

  /*
    CONSTRUCTOR
   */

  function Panel(info) {
    this.title = Locale.tr("Apps");
    this.icon = "fa-shopping-cart";

    this.element = info[XML_ROOT.toUpperCase()];

    return this;
  };

  Panel.PANEL_ID = PANEL_ID;
  Panel.prototype.html = _html;
  Panel.prototype.setup = _setup;

  return Panel;

  /*
    FUNCTION DEFINITIONS
   */

  function _html() {
    var marketPlaceApps = [];

    if (this.element.MARKETPLACEAPPS.ID != undefined){
      marketPlaceApps = this.element.MARKETPLACEAPPS.ID;

      if (!$.isArray(marketPlaceApps)){
        marketPlaceApps = [marketPlaceApps];
      }
    }

    var opts = {
      info: true,
      select: true,
      selectOptions: {
        read_only: true,
        fixed_ids: marketPlaceApps
      }
    };

    this.marketPlaceAppsDataTable = new MarketPlaceAppsTable(MARKETPLACEAPPS_TABLE_ID, opts);

    return this.marketPlaceAppsDataTable.dataTableHTML;
  }

  function _setup(context) {
    this.marketPlaceAppsDataTable.initialize();
    this.marketPlaceAppsDataTable.refreshResourceTableSelect();

    return false;
  }
})
